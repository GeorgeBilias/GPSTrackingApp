package com.example.myapplication;



import static androidx.core.content.PermissionChecker.checkSelfPermission;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URI;
import java.net.URISyntaxException;

public class MainActivity extends Activity {
    private static final String TAG = "MainActivity";
    private static final int PICK_GPX_FILE_REQUEST = 1;
    public String globalPath = "";
    Button btn;

    EditText input;

    TextView label;

    TextView label2;
    Handler handler;

    Button menuButton;

    Button button2;









    @Override
    public void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        setContentView(R.layout.activity_main);


        //openFilePicker();

        button2 = (Button) findViewById(R.id.button2);

        button2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(MainActivity.this,MainActivity2.class);
                startActivity(intent);




            }
        });
        menuButton = (Button) findViewById(R.id.menuButton);

        menuButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                openFilePicker();



                //Log.d("PLEASE SHOW ", "PATH: " +path);

                // MyThread t1 = new MyThread(globalPath,handler);
                // t1.start();
            }
        });
        Log.d("myTag", "BUTTON ");

        //ActivityCompat.requestPermissions(this, new String[]{
        //Manifest.permission.READ_EXTERNAL_STORAGE}, 0);

        if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            Log.d("r","granted already");
        } else {

            int PERMISSION_EXTERNAL_STORAGE = 1;
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    PERMISSION_EXTERNAL_STORAGE);
            Log.d("r","granted");
        }


        if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            Log.d("r","granted permission");
        }

        int rslt = checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE);
        Log.d("lol",String.valueOf(rslt));
        Log.d("lol",String.valueOf(PackageManager.PERMISSION_GRANTED));





        handler = new Handler(Looper.getMainLooper(), new Handler.Callback() {
            @Override
            public boolean handleMessage(@NonNull Message message) {
                String result = message.getData().getString("result");

                label.setText(result);

                return true;
            }
        });


        label = (TextView) findViewById(R.id.label);
        label2 = (TextView) findViewById(R.id.label2);


    }

    private void openFilePicker() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*"); // Set the MIME type to select all file types
        intent.addCategory(Intent.CATEGORY_OPENABLE);

        // Start the file picker activity
        startActivityForResult(intent, PICK_GPX_FILE_REQUEST);
        //Log.d("PAPA","File size: " + intent.getData().getPath());
        // return intent.getData().getPath();
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_GPX_FILE_REQUEST && resultCode == RESULT_OK) {
            if (data != null) {
                Uri uri = data.getData();

                File f = new File(uri.getPath());
                String filename = f.getName();
                //String FileDirectory =  c.getFilesDir().getAbsolutePath()+"/"+filename;

                ContextWrapper c = new ContextWrapper(this);

                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);

                String FileDirectory =  c.getFilesDir().getAbsolutePath()+"/"+filename;


                Log.e("ANNA",FileDirectory);
                Log.e("papa","here");
                MyThread t1 = new MyThread(FileDirectory, handler,label,label2);
                t1.start();


            }
        }


    }



    private String getFilePathFromUri(@NonNull Uri uri) {
        String filePath1;

        if ("file".equalsIgnoreCase(uri.getScheme())) {
            filePath1 = uri.getPath();
            return filePath1;
        } else {
            String[] projection = {MediaStore.Files.FileColumns.DATA};
            Cursor cursor = null;
            try {
                cursor = getContentResolver().query(uri, projection, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA);
                    filePath1 = cursor.getString(columnIndex);
                    return filePath1;
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }

        return "";
    }




    private String getDataColumn(Context context, Uri uri, String selection, String[] selectionArgs) {
        String[] projection = {MediaStore.Images.Media.DATA};
        try (Cursor cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                return cursor.getString(columnIndex);
            }
        }
        return null;
    }
    private String handleSelectedFile(@NonNull Uri fileUri) {
        // Process the selected GPX file URI
        // You can retrieve the file path from the URI and read the file using FileInputStream or other methods
        String filePath = fileUri.getPath();
        Log.d(TAG, "Selected GPX file path: " + filePath);
        return filePath;
        // Once you have the file path, you can read and process the GPX file as per your requirements
    }
    @RequiresApi(api = Build.VERSION_CODES.Q)
    public void buttonOpenFile(View view){
        Log.d("myTag", "MenuButton ");
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent,42);

    }








}